"""genaifabric — provider-agnostic GenAI runtime library.

Public API::

    from genaifabric import GenAIFabric

    runtime = GenAIFabric()
    result = runtime.run(instruction="Say hello", provider="mock")
    print(result.success)   # True
    print(result.output)    # "mock response"
"""

from genaifabric.runtime import GenAIFabric

__all__ = ["GenAIFabric"]
