"""Gemini provider implementation using the official Google GenAI Python SDK."""

from __future__ import annotations

import os
from typing import Optional

from genaifabric.models import GenerationResult
from genaifabric.providers.base import BaseProvider
from genaifabric.providers.errors import ProviderError, ErrorCategory
from genaifabric.providers._prompt import serialize_prompt
from genaifabric.providers._imports import guard_import


class GeminiProvider(BaseProvider):
    """Gemini provider using official Google GenAI Python SDK.

    Implements explicit model and API key configuration with normalized
    success/failure mapping to GenerationResult.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
    ) -> None:
        """Initialize Gemini provider.

        Args:
            api_key: API key for Gemini. If not provided, uses GEMINI_API_KEY env var.
            model: Model name (required, e.g., 'gemini-pro').
                   Must be explicitly provided; no implicit default.

        Raises:
            ProviderError: If api_key is missing or model is not provided.
        """
        # Resolve API key with precedence: constructor > environment
        self._api_key = api_key
        if not self._api_key or not self._api_key.strip():
            self._api_key = os.environ.get("GEMINI_API_KEY")

        if not self._api_key or not self._api_key.strip():
            raise ProviderError(
                category=ErrorCategory.MISSING_API_KEY,
                message="Gemini API key not provided",
                provider="gemini",
                hint="Set GEMINI_API_KEY environment variable or pass api_key to constructor",
            )

        # Validate model is provided
        if not model or not model.strip():
            raise ProviderError(
                category=ErrorCategory.MISSING_MODEL,
                message="Model name is required for Gemini provider",
                provider="gemini",
                hint="Pass model='gemini-pro' or similar to constructor",
            )

        self._model = model.strip()

        # Import and initialize Gemini client (lazy import to allow optional dependency)
        try:
            genai_module = guard_import("google.genai", "google-genai", "gemini")
            self._client = genai_module.Client(api_key=self._api_key)
        except ProviderError:
            raise
        except Exception as e:
            raise ProviderError(
                category=ErrorCategory.SDK_UNKNOWN,
                message=f"Failed to initialize Gemini SDK: {e}",
                provider="gemini",
                hint="Ensure google-genai package is installed: pip install google-genai",
            ) from e

    def generate(
        self,
        instruction: str,
        input: dict[str, object] | None = None,  # noqa: A002
        model: str | None = None,
    ) -> GenerationResult:
        """Execute generation via Gemini API.

        Args:
            instruction: The prompt instruction.
            input: Optional context dict to append as JSON.
            model: Optional model override. If provided, use this model instead of
                   the configured default. If None, use self._model (the default).

        Returns:
            Normalized GenerationResult with success/failure status.
        """
        # Resolve effective model: override > configured default
        effective_model = model if model else self._model
        
        try:
            # Construct deterministic prompt
            prompt = serialize_prompt(instruction, input)
        except ValueError as e:
            # Non-serializable input
            return GenerationResult(
                output=None,
                provider="gemini",
                metadata={},
                success=False,
                error=f"gemini: INVALID_CONFIG – {str(e)}",
            )

        try:
            # Call Gemini SDK
            response = self._client.models.generate_content(
                model=effective_model,
                contents=prompt,
            )

            # Extract response text
            if not response or not response.text:
                return GenerationResult(
                    output=None,
                    provider="gemini",
                    metadata={},
                    success=False,
                    error="gemini: PROVIDER_SERVER_ERROR – Empty response from Gemini",
                )

            output = response.text

            # Build metadata
            metadata: dict[str, object] = {}
            if effective_model:
                metadata["model"] = effective_model
            if hasattr(response, "usage_metadata") and response.usage_metadata:
                metadata["usage"] = {
                    "prompt_tokens": response.usage_metadata.prompt_token_count,
                    "completion_tokens": response.usage_metadata.candidates_token_count,
                }

            return GenerationResult(
                output=output,
                provider="gemini",
                metadata=metadata,
                success=True,
                error=None,
            )

        except ProviderError:
            # Re-raise ProviderError as-is
            raise
        except Exception as e:
            # Normalize unexpected exception to failure result
            error_msg = str(e)
            if "Unauthorized" in error_msg or "401" in error_msg:
                category = "AUTH_FAILED"
                hint = "Check that GEMINI_API_KEY is valid"
            elif "Rate limit" in error_msg or "429" in error_msg:
                category = "RATE_LIMITED"
                hint = "Wait before retrying"
            elif "Timeout" in error_msg:
                category = "TIMEOUT"
                hint = "Retry the request"
            elif "model not found" in error_msg.lower():
                category = "INVALID_CONFIG"
                hint = f"Verify model '{effective_model}' exists and is available"
            else:
                category = "PROVIDER_SERVER_ERROR"
                hint = "Check Gemini service status"

            return GenerationResult(
                output=None,
                provider="gemini",
                metadata={},
                success=False,
                error=f"gemini: {category} – {error_msg} ({hint})",
            )
