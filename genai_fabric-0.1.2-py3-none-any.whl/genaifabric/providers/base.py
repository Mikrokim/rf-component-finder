"""Abstract base class that every genaifabric provider must implement."""

from __future__ import annotations

from abc import ABC, abstractmethod

from genaifabric.models import GenerationResult


class BaseProvider(ABC):
    """Contract for all genaifabric provider implementations.

    Each provider is a separate module under ``genaifabric/providers/``.  The
    runtime dispatch layer calls only :meth:`generate`; no provider-specific
    logic is permitted in ``runtime.py`` or ``__init__.py``.

    Parameter naming note:
        The ``input`` parameter shadows the Python built-in ``input()``.  This
        is intentional — the name is idiomatic for data passed into a generation
        call and the built-in is never needed inside a provider implementation.
    """

    @abstractmethod
    def generate(
        self,
        instruction: str,
        input: dict[str, object] | None,  # noqa: A002
        model: str | None = None,
    ) -> GenerationResult:
        """Execute a generation request and return a normalized result.

        Args:
            instruction: The natural-language instruction to execute.  May be
                an empty string; providers must handle it gracefully.
            input: Optional supplementary data dict.  Providers are responsible
                for interpreting the values; the runtime does not validate it.
            model: Optional model override. If provided, use this model instead of
                the provider's configured default. If None, use the provider's
                default model. Providers should resolve the effective model and
                include it in metadata when available.

        Returns:
            A :class:`~genaifabric.models.GenerationResult` instance.  Must
            never be ``None`` and must never expose raw provider-internal data.

        Raises:
            Providers MUST NOT raise for expected failure conditions (e.g., rate
            limits, API errors) — return ``GenerationResult(success=False, …)``
            instead.  Unexpected programming errors may propagate as exceptions.
        """
