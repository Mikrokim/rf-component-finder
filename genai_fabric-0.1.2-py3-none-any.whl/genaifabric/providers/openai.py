"""OpenAI provider implementation using the official OpenAI Python SDK."""

from __future__ import annotations

import os
from typing import Optional

from genaifabric.models import GenerationResult
from genaifabric.providers.base import BaseProvider
from genaifabric.providers.errors import ProviderError, ErrorCategory
from genaifabric.providers._prompt import serialize_prompt
from genaifabric.providers._imports import guard_import


class OpenAIProvider(BaseProvider):
    """OpenAI provider using official OpenAI Python SDK.

    Implements explicit model and API key configuration with normalized
    success/failure mapping to GenerationResult.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
    ) -> None:
        """Initialize OpenAI provider.

        Args:
            api_key: API key for OpenAI. If not provided, uses OPENAI_API_KEY env var.
            model: Model name (required, e.g., 'gpt-4', 'gpt-3.5-turbo').
                   Must be explicitly provided; no implicit default.

        Raises:
            ProviderError: If api_key is missing or model is not provided.
        """
        # Resolve API key with precedence: constructor > environment
        self._api_key = api_key
        if not self._api_key or not self._api_key.strip():
            self._api_key = os.environ.get("OPENAI_API_KEY")

        if not self._api_key or not self._api_key.strip():
            raise ProviderError(
                category=ErrorCategory.MISSING_API_KEY,
                message="OpenAI API key not provided",
                provider="openai",
                hint="Set OPENAI_API_KEY environment variable or pass api_key to constructor",
            )

        # Validate model is provided
        if not model or not model.strip():
            raise ProviderError(
                category=ErrorCategory.MISSING_MODEL,
                message="Model name is required for OpenAI provider",
                provider="openai",
                hint="Pass model='gpt-4' or similar to constructor",
            )

        self._model = model.strip()

        # Import and initialize OpenAI client (lazy import to allow optional dependency)
        try:
            openai_module = guard_import("openai", "openai", "openai")
            self._client = openai_module.OpenAI(api_key=self._api_key)
        except ProviderError:
            raise
        except Exception as e:
            raise ProviderError(
                category=ErrorCategory.SDK_UNKNOWN,
                message=f"Failed to initialize OpenAI SDK: {e}",
                provider="openai",
                hint="Ensure openai package is installed: pip install openai",
            ) from e

    def generate(
        self,
        instruction: str,
        input: dict[str, object] | None = None,  # noqa: A002
        model: str | None = None,
    ) -> GenerationResult:
        """Execute generation via OpenAI API.

        Args:
            instruction: The prompt instruction.
            input: Optional context dict to append as JSON.
            model: Optional model override. If provided, use this model instead of
                   the configured default. If None, use self._model (the default).

        Returns:
            Normalized GenerationResult with success/failure status.
        """
        # Resolve effective model: override > configured default
        effective_model = model if model else self._model
        
        try:
            # Construct deterministic prompt
            prompt = serialize_prompt(instruction, input)
        except ValueError as e:
            # Non-serializable input
            return GenerationResult(
                output=None,
                provider="openai",
                metadata={},
                success=False,
                error=f"openai: INVALID_CONFIG – {str(e)}",
            )

        try:
            # Call OpenAI SDK using Chat Completions (supports both chat and completion models)
            response = self._client.chat.completions.create(
                model=effective_model,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                max_tokens=2000,
            )

            # Extract response text
            if not response.choices or not response.choices[0].message.content:
                return GenerationResult(
                    output=None,
                    provider="openai",
                    metadata={},
                    success=False,
                    error="openai: PROVIDER_SERVER_ERROR – Empty response from OpenAI",
                )

            output = response.choices[0].message.content

            # Build metadata (providers can include optional fields)
            metadata: dict[str, object] = {}
            if effective_model:
                metadata["model"] = effective_model
            if hasattr(response, "usage") and response.usage:
                metadata["usage"] = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }
            if hasattr(response.choices[0], "finish_reason"):
                metadata["finish_reason"] = response.choices[0].finish_reason

            return GenerationResult(
                output=output,
                provider="openai",
                metadata=metadata,
                success=True,
                error=None,
            )

        except ProviderError:
            # Re-raise ProviderError as-is
            raise
        except Exception as e:
            # Normalize unexpected exception to failure result
            error_msg = str(e)
            if "Unauthorized" in error_msg or "401" in error_msg:
                category = "AUTH_FAILED"
                hint = "Check that OPENAI_API_KEY is valid"
            elif "Rate limit" in error_msg or "429" in error_msg:
                category = "RATE_LIMITED"
                hint = "Wait before retrying"
            elif "Timeout" in error_msg or "timeout" in error_msg:
                category = "TIMEOUT"
                hint = "Retry the request"
            elif "model not found" in error_msg.lower():
                category = "INVALID_CONFIG"
                hint = f"Verify model '{effective_model}' exists and is available"
            else:
                category = "PROVIDER_SERVER_ERROR"
                hint = "Check OpenAI service status"

            return GenerationResult(
                output=None,
                provider="openai",
                metadata={},
                success=False,
                error=f"openai: {category} – {error_msg} ({hint})",
            )
