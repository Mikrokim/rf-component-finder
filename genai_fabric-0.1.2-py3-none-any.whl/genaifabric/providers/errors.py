"""Provider error types and handling."""

from enum import Enum
from typing import Optional


class ErrorCategory(str, Enum):
    """Canonical error categories for provider failures."""

    MISSING_API_KEY = "MISSING_API_KEY"
    MISSING_MODEL = "MISSING_MODEL"
    INVALID_CONFIG = "INVALID_CONFIG"
    AUTH_FAILED = "AUTH_FAILED"
    RATE_LIMITED = "RATE_LIMITED"
    TIMEOUT = "TIMEOUT"
    NETWORK_ERROR = "NETWORK_ERROR"
    PROVIDER_SERVER_ERROR = "PROVIDER_SERVER_ERROR"
    CONTENT_BLOCKED = "CONTENT_BLOCKED"
    SDK_UNKNOWN = "SDK_UNKNOWN"


class ProviderError(Exception):
    """Exception raised by provider implementations for configuration and runtime errors.

    This exception is caught by the runtime and normalized into a GenerationResult
    with success=False.
    """

    def __init__(
        self,
        category: ErrorCategory,
        message: str,
        provider: str = "unknown",
        hint: Optional[str] = None,
    ):
        """Initialize a ProviderError.

        Args:
            category: ErrorCategory enum value
            message: Descriptive error message
            provider: Name of the provider that raised the error
            hint: Actionable hint for the user
        """
        self.category = category
        self.message = message
        self.provider = provider
        self.hint = hint

        # Format: "provider: CATEGORY – message (hint if present)"
        error_text = f"{provider}: {category.value} – {message}"
        if hint:
            error_text += f" ({hint})"

        super().__init__(error_text)
