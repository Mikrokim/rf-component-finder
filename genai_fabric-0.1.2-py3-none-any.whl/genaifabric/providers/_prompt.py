"""Deterministic prompt construction for provider SDKs."""

import json
from typing import Any, Optional


def serialize_prompt(
    instruction: str,
    input_data: Optional[dict[str, Any]] = None,
) -> str:
    """Create a deterministic prompt from instruction and optional context.

    Format: instruction + "\nContext: " + json.dumps(input_data, sort_keys=True)

    Args:
        instruction: The base instruction text
        input_data: Optional context dict to be serialized as JSON

    Returns:
        Deterministic prompt string, or just instruction if input_data is None

    Raises:
        ValueError: If input_data contains non-JSON-serializable values
    """
    if input_data is None:
        return instruction

    try:
        # Serialize deterministically with sorted keys
        context_json = json.dumps(input_data, sort_keys=True)
    except (TypeError, ValueError) as e:
        raise ValueError(
            f"Cannot serialize input to JSON (contains non-serializable values): {e}"
        ) from e

    # Format: instruction + newline + "Context: " + json + no trailing whitespace
    prompt = f"{instruction}\nContext: {context_json}"
    return prompt
