"""Mock provider — deterministic, hermetic, zero network I/O."""

from __future__ import annotations

from genaifabric.models import GenerationResult
from genaifabric.providers.base import BaseProvider

_MOCK_OUTPUT = "mock response"
_MOCK_PROVIDER_NAME = "mock"


class MockProvider(BaseProvider):
    """Built-in provider for testing and local development.

    Always returns a fixed, deterministic :class:`~genaifabric.models.GenerationResult`
    regardless of ``instruction`` or ``input``.  Never makes network or
    filesystem calls, so it is safe for unit tests.

    Registration key: ``"mock"`` (exact, case-sensitive).

    Fixed return value::

        GenerationResult(
            output="mock response",
            provider="mock",
            metadata={},
            success=True,
            error=None,
        )
    """

    def generate(
        self,
        instruction: str,
        input: dict[str, object] | None,  # noqa: A002
        model: str | None = None,
    ) -> GenerationResult:
        metadata: dict[str, object] = {}
        if model:
            metadata["model"] = model
        
        return GenerationResult(
            output=_MOCK_OUTPUT,
            provider=_MOCK_PROVIDER_NAME,
            metadata=metadata,
            success=True,
            error=None,
        )
