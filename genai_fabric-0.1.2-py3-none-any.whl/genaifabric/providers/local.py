"""Local provider implementation using Ollama runtime integration."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any

from genaifabric.models import GenerationResult
from genaifabric.providers.base import BaseProvider
from genaifabric.providers.errors import ErrorCategory, ProviderError
from genaifabric.utils.text import chunk_text


class LocalProvider(BaseProvider):
    """Local provider implementation supporting Ollama runtime.

    Dispatches generation requests to a local Ollama instance with configurable
    model selection and standardized error handling.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        timeout_seconds: float = 120.0,
        allowed_models: list[str] | None = None,
        max_chunk_chars: int = 8000,
        overlap_chars: int = 0,
    ) -> None:
        """Initialize local provider with Ollama configuration.

        Args:
            base_url: Ollama API base URL (default: localhost:11434).
            timeout_seconds: Request timeout in seconds.
            allowed_models: List of allowed model identifiers (e.g. qwen3:8b, llama3.1:8b).
                           If None, defaults to qwen3:8b and llama3.1:8b for v1.
            max_chunk_chars: Maximum prompt length (in characters) sent in a single
                           Ollama call. Longer prompts are split into chunks, generated
                           per chunk, and aggregated. Default (8000) tuned empirically
                           (T028) against qwen3:8b and llama3.1:8b: both truncate beyond
                           ~2975 prompt tokens (~5.2 English chars/token); 8000 stays
                           safely below that with room for the generated output.
            overlap_chars: Characters of overlap between consecutive chunks (default 0).
        """
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.allowed_models = allowed_models or ["qwen3:8b", "llama3.1:8b"]
        self.max_chunk_chars = max_chunk_chars
        self.overlap_chars = overlap_chars

    def generate(
        self,
        instruction: str,
        input: dict[str, object] | None = None,  # noqa: A002
        model: str | None = None,
    ) -> GenerationResult:
        """Execute generation via local Ollama runtime.

        Args:
            instruction: The natural-language instruction to execute.
            input: Optional supplementary data dict.
            model: Optional model override.

        Returns:
            A GenerationResult instance.
        """
        # Validate and resolve effective model
        effective_model = model
        if not effective_model or not effective_model.strip():
            return GenerationResult(
                output=None,
                provider="local",
                metadata={},
                success=False,
                error="local: INVALID_CONFIG – Model is required for local provider",
            )

        effective_model = effective_model.strip()

        # Check if model is in allowed list
        if effective_model not in self.allowed_models:
            return GenerationResult(
                output=None,
                provider="local",
                metadata={},
                success=False,
                error=f"local: MISSING_MODEL – Model '{effective_model}' is not available locally",
            )

        # Construct prompt from instruction and optional input
        prompt = self._construct_prompt(instruction, input)

        # Chunking is intentionally disabled: always send the full prompt in a
        # single Ollama call. The chunking helpers (_generate_chunked,
        # chunk_text) are retained but unused; see feature 005-text-chunking.
        return self._generate_once(effective_model, prompt)

    def _generate_once(self, model: str, prompt: str) -> GenerationResult:
        """Execute a single Ollama call and map the response to a GenerationResult.

        Args:
            model: The resolved model identifier.
            prompt: The prompt to send.

        Returns:
            A normalized GenerationResult; never raises for expected failures.
        """
        try:
            response = self._call_ollama(model, prompt)
            output = response.get("response", "").strip()

            if not output:
                return GenerationResult(
                    output=None,
                    provider="local",
                    metadata={},
                    success=False,
                    error="local: PROVIDER_SERVER_ERROR – Empty response from Ollama",
                )

            metadata: dict[str, object] = {
                "model": model,
                "runtime": "ollama",
            }

            return GenerationResult(
                output=output,
                provider="local",
                metadata=metadata,
                success=True,
                error=None,
            )

        except urllib.error.URLError as e:
            return GenerationResult(
                output=None,
                provider="local",
                metadata={},
                success=False,
                error=f"local: NETWORK_ERROR – Cannot reach Ollama at {self.base_url}: {str(e)}",
            )

        except TimeoutError as e:
            return GenerationResult(
                output=None,
                provider="local",
                metadata={},
                success=False,
                error=f"local: TIMEOUT – Ollama request timed out after {self.timeout_seconds}s: {str(e)}",
            )

        except Exception as e:
            return GenerationResult(
                output=None,
                provider="local",
                metadata={},
                success=False,
                error=f"local: PROVIDER_SERVER_ERROR – Ollama generation failed: {str(e)}",
            )

    def _generate_chunked(self, model: str, prompt: str) -> GenerationResult:
        """Split an oversized prompt, generate each chunk, and aggregate outputs.

        Each chunk is sent in its own Ollama call. On the first chunk failure the
        standardized failure result is returned. On success the per-chunk outputs
        are joined, in order, into a single result.

        Args:
            model: The resolved model identifier.
            prompt: The oversized prompt to chunk.

        Returns:
            A normalized GenerationResult with chunk metadata; never raises.
        """
        chunks = chunk_text(prompt, self.max_chunk_chars, self.overlap_chars)

        outputs: list[str] = []
        for chunk in chunks:
            result = self._generate_once(model, chunk)
            if not result.success:
                return result
            outputs.append(result.output or "")

        # Reconnect the parts: join the ordered per-chunk outputs into one result.
        aggregated = "\n".join(outputs)

        return GenerationResult(
            output=aggregated,
            provider="local",
            metadata={
                "model": model,
                "runtime": "ollama",
                "chunked": True,
                "chunks": len(chunks),
            },
            success=True,
            error=None,
        )

    def _construct_prompt(
        self,
        instruction: str,
        input_data: dict[str, object] | None = None,
    ) -> str:
        """Construct deterministic prompt from instruction and optional input.

        Args:
            instruction: The instruction text.
            input_data: Optional context dict.

        Returns:
            Deterministic prompt string.
        """
        prompt = instruction
        if input_data:
            try:
                # Serialize input deterministically with sorted keys
                input_json = json.dumps(input_data, sort_keys=True)
                prompt = f"{instruction}\n\nContext:\n{input_json}"
            except (TypeError, ValueError):
                # If input is not JSON-serializable, append as string representation
                prompt = f"{instruction}\n\nContext:\n{str(input_data)}"
        return prompt

    def _call_ollama(
        self,
        model: str,
        prompt: str,
    ) -> dict[str, Any]:
        """Call Ollama API to generate text.

        Args:
            model: Model identifier.
            prompt: The prompt text.

        Returns:
            Parsed JSON response from Ollama.

        Raises:
            urllib.error.URLError: If network error occurs.
            TimeoutError: If request times out.
            ValueError: If response is malformed.
        """
        url = f"{self.base_url}/api/generate"
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "format": "json"
        }

        headers = {
            "Content-Type": "application/json",
        }

        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )

        try:
            with urllib.request.urlopen(
                request,
                timeout=self.timeout_seconds,
            ) as response:
                if response.status != 200:
                    raise ValueError(
                        f"Ollama returned status {response.status}: {response.reason}"
                    )

                response_data = json.loads(response.read().decode("utf-8"))
                return response_data

        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise ValueError(f"Model '{model}' not found in Ollama")
            raise

        except urllib.error.URLError as e:
            raise

        except json.JSONDecodeError as e:
            raise ValueError(f"Malformed response from Ollama: {str(e)}")

