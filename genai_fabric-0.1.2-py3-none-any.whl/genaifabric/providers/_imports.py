"""Helpers for guarding optional SDK imports."""

from typing import Any
from genaifabric.providers.errors import ProviderError, ErrorCategory


def guard_import(module_name: str, package_name: str, provider_name: str) -> Any:
    """Guard import of an optional SDK module.

    If the import fails (ImportError or ModuleNotFoundError), raises ProviderError
    with SDK_UNKNOWN category and actionable hint.

    Args:
        module_name: Full module name to import (e.g., 'openai', 'google.genai')
        package_name: Display name of the package (e.g., 'openai', 'google-genai')
        provider_name: Name of the provider (e.g., 'openai', 'gemini')

    Returns:
        The imported module

    Raises:
        ProviderError: If module cannot be imported
    """
    try:
        return __import__(module_name, fromlist=[module_name.split(".")[-1]])
    except (ImportError, ModuleNotFoundError) as e:
        raise ProviderError(
            category=ErrorCategory.SDK_UNKNOWN,
            message=f"SDK for {provider_name} provider not installed",
            provider=provider_name,
            hint=f"Install with: pip install genaifabric[{provider_name}] or pip install {package_name}",
        ) from e


def get_or_none(obj: Any, attr: str, default: Any = None) -> Any:
    """Safely get attribute from object or return default."""
    return getattr(obj, attr, default)
