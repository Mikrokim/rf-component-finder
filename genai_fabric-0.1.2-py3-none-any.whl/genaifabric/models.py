"""Data models for genaifabric — normalized result types only."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class GenerationResult:
    """Normalized result returned by GenAIFabric.run().

    All fields are always present.  The caller MUST check ``success`` before
    using ``output``; on failure ``output`` is ``None`` and ``error`` carries a
    description of what went wrong.

    Invariants:
        - ``success is True``  → ``output`` is a non-empty str; ``error`` is None.
        - ``success is False`` → ``output`` is None; ``error`` is a non-empty str.
        - ``provider`` is always the name that was requested, regardless of
          whether the lookup succeeded.
        - ``metadata`` is always a dict (never None); may be empty (``{}``).
    """

    output: str | None
    provider: str
    metadata: dict[str, object]
    success: bool
    error: str | None
