"""Shared, provider-agnostic utilities for genaifabric.

These helpers depend on no provider and perform no I/O, so they can be reused
across providers and unit-tested in isolation.
"""

from genaifabric.utils.text import chunk_text

__all__ = ["chunk_text"]
