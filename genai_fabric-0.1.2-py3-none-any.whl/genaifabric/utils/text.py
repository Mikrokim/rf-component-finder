"""Dependency-free text chunking utilities.

:func:`chunk_text` splits an oversized text into ordered chunks bounded by a
maximum character count. Cuts prefer natural boundaries in descending order —
paragraph, then sentence, then word — and fall back to a mid-word character cut
only when a single word is itself longer than the limit. All original content is
preserved: for ``overlap_chars == 0`` the concatenation of the returned chunks
reproduces the input exactly.

Size is measured purely by character count (``len``); there is no token
estimation and no third-party dependency.
"""

from __future__ import annotations

# Boundary separators, from coarsest to finest. A cut is made immediately after
# the chosen separator so the separator stays with the preceding chunk.
_PARAGRAPH = "\n\n"
_SENTENCE_ENDS = (". ", "! ", "? ", ".\n", "!\n", "?\n")
_WORD = " "


def chunk_text(text: str, max_chars: int, overlap_chars: int = 0) -> list[str]:
    """Split ``text`` into ordered chunks, each at most ``max_chars`` long.

    Args:
        text: The text to split.
        max_chars: Maximum characters per chunk. Must be positive.
        overlap_chars: Number of trailing characters of each chunk to repeat at
            the start of the next chunk. Defaults to 0 (no overlap). Must be
            non-negative and smaller than ``max_chars``.

    Returns:
        An ordered list of chunks. Each chunk has ``len`` <= ``max_chars``. When
        ``overlap_chars == 0`` the chunks are contiguous and their concatenation
        reproduces ``text`` exactly. Text within the limit is returned as a
        single-element list equal to ``text``.

    Raises:
        ValueError: If ``max_chars`` is not positive, or ``overlap_chars`` is
            negative or not smaller than ``max_chars``.
    """
    if max_chars <= 0:
        raise ValueError("max_chars must be positive")
    if overlap_chars < 0:
        raise ValueError("overlap_chars must be non-negative")
    if overlap_chars >= max_chars:
        raise ValueError("overlap_chars must be smaller than max_chars")

    if len(text) <= max_chars:
        return [text]

    chunks: list[str] = []
    start = 0
    n = len(text)

    while start < n:
        end = min(start + max_chars, n)
        if end < n:
            end = _find_cut(text, start, end)
        chunks.append(text[start:end])

        if end >= n:
            break

        if overlap_chars > 0:
            next_start = end - overlap_chars
            # Guarantee forward progress even if overlap would rewind past start.
            start = next_start if next_start > start else end
        else:
            start = end

    return chunks


def _find_cut(text: str, start: int, end: int) -> int:
    """Return the best cut index in ``(start, end]`` for the chunk at ``start``.

    Prefers, in order, a paragraph break, a sentence end, then a word boundary
    within ``text[start:end]``. Falls back to ``end`` (a hard mid-word cut) only
    when no boundary is found — e.g. a single word longer than the window. The
    returned index is always greater than ``start``, guaranteeing progress.
    """
    window = text[start:end]

    # 1. Paragraph boundary.
    idx = window.rfind(_PARAGRAPH)
    if idx != -1:
        return start + idx + len(_PARAGRAPH)

    # 2. Sentence boundary — the latest sentence end in the window.
    best = -1
    for sep in _SENTENCE_ENDS:
        i = window.rfind(sep)
        if i != -1:
            best = max(best, i + len(sep))
    if best != -1:
        return start + best

    # 3. Word boundary — cut just after the last space.
    idx = window.rfind(_WORD)
    if idx != -1:
        return start + idx + len(_WORD)

    # 4. Last resort: a single word longer than max_chars — hard cut.
    return end
