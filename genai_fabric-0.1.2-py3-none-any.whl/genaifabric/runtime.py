"""GenAIFabric — public runtime class for genai-fabric."""

from __future__ import annotations

from typing import Optional

from genaifabric.models import GenerationResult
from genaifabric.providers.base import BaseProvider
from genaifabric.providers.local import LocalProvider
from genaifabric.providers.mock import MockProvider


class GenAIFabric:
    """Provider-agnostic GenAI runtime.

    Dispatches :meth:`run` calls to the registered provider identified by the
    ``provider`` argument. The built-in default provider is ``"mock"``.
    Additional providers (openai, gemini) can be injected via the optional
    constructor ``provider_map`` parameter.

    Provider lookup is **case-sensitive and exact-match**.  ``"mock"`` resolves
    to the built-in mock provider; ``"Mock"`` does not. Unknown provider names
    never raise — they return a failure result.

    All results are :class:`~genaifabric.models.GenerationResult` instances.
    """

    def __init__(
        self,
        provider_map: Optional[dict[str, BaseProvider]] = None,
    ) -> None:
        """Initialize runtime with optional provider-map injection.

        Args:
            provider_map: Optional dict mapping provider keys to BaseProvider instances.
                If provided, these providers are used instead of built-in defaults.
                If None, runtime initializes built-in providers (mock, openai, gemini).
        """
        if provider_map is not None:
            self._providers = provider_map
        else:
            # Initialize built-in defaults
            self._providers = self._initialize_builtin_providers()

    @staticmethod
    def _initialize_builtin_providers() -> dict[str, BaseProvider]:
        """Initialize built-in provider instances.

        Returns:
            Dict mapping provider keys to BaseProvider instances.
            Always includes 'mock' and 'local'. OpenAI and Gemini providers must be
            explicitly registered via provider_map if needed, as they require API keys.
        """
        providers: dict[str, BaseProvider] = {
            "mock": MockProvider(),
            "local": LocalProvider(),
        }
        return providers

    def run(
        self,
        instruction: str,
        provider: str,
        model: str | None = None,
        input: dict[str, object] | None = None,  # noqa: A002
    ) -> GenerationResult:
        """Dispatch an instruction to the named provider with optional model override.

        Args:
            instruction: The natural-language instruction to execute.
            provider: Registered provider name (case-sensitive, e.g. ``"mock"``).
            model: Optional model override. If provided, this model will be used
                instead of the provider's configured default. Whitespace-only
                strings are treated as None. Unknown models are passed through
                to the provider for provider-specific handling.
            input: Optional supplementary data passed through to the provider.

        Returns:
            :class:`~genaifabric.models.GenerationResult` — always present,
            never raises for provider-lookup or model errors.
        """
        provider_instance = self._providers.get(provider)
        if provider_instance is None:
            return GenerationResult(
                output=None,
                provider=provider,
                metadata={},
                success=False,
                error=f"Unknown provider: '{provider}'",
            )
        
        # Normalize model: treat whitespace-only strings as None
        normalized_model: str | None = None
        if model is not None and model.strip():
            normalized_model = model.strip()
        
        try:
            return provider_instance.generate(instruction, input, normalized_model)
        except Exception as e:
            # Catch any unhandled exceptions from provider and normalize to GenerationResult
            return GenerationResult(
                output=None,
                provider=provider,
                metadata={},
                success=False,
                error=f"Provider error: {str(e)}",
            )
